**What server is the issue present on?:**


**When did the issue occur?:**


**Describe the issue in depth:**


**What may be the cause of the issue?:**


**Name the plugins/mods involved in the issue:**


**Extra information:**